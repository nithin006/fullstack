Normal Text

# Full Stack JavaScript Bootcamp 2.0

## Full Stack JavaScript Bootcamp 2.0

### Full Stack JavaScript Bootcamp 2.0

_Batch 2.0_

**Batch 2.0**

**Bold / Strong**

~~9999~~ Rs. 1000000

Link

[Know More](https://ineuron.ai)
[Know More](https://ineuron.ai 'Company name')

![Alter Text](https://ineuron.ai/images/ineuron-logo.png)

Tables

| Monday | Tues  | Wednesday |
| ------ | ----- | --------- |
| Sci    | Maths | Bio       |

My Name is `patience`

```javascript
let a = 100;
```

Quotes

> Learn to have Patience, things will come!

1. Arpit
1. Dipesh
1. Snehal
    1. Anurag

-   Anurag
-   raman
-   Arpit

![](https://img.shields.io/badge/Topic-Github-green)
![](https://img.shields.io/badge/Topic-MarkDown-yellowgreen)
